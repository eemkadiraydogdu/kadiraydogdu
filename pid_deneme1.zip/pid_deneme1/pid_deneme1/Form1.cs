﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SimpleTCP;

namespace pid_deneme1
{
    public partial class frmmain: Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-4UO9E27\\SQLEXPRESS;Initial Catalog=pid_server;Integrated Security=True");
        public frmmain()
        {
            InitializeComponent();
        }

        SimpleTcpClient client;
        public int deg = 1;

        private void frmmain_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'pid_serverDataSet2.table_pid' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.table_pidTableAdapter2.Fill(this.pid_serverDataSet2.table_pid);
            // TODO: Bu kod satırı 'pid_serverDataSet3.table_pid' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.table_pidTableAdapter1.Fill(this.pid_serverDataSet3.table_pid);
            listele();
            timer1.Interval = 200000;
            timer1.Start();
            client = new SimpleTcpClient();
            client.StringEncoder = Encoding.UTF8;

            //client.DataReceived += Client_DataReceived;
        }

        void listele()
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "select * FROM table_pid WHERE KALKIS_YERI='KONYA   ' and KALKIS_SAATI between CONVERT(Varchar(8), GETDATE()-'00:30:00', 108) and '23:59:59' ORDER BY KALKIS_SAATI ASC";
                SqlDataAdapter adpr = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adpr.Fill(ds, "table_pid");
                dataGridView1.DataSource = ds.Tables["table_pid"];
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[5].DefaultCellStyle.Format = "HH\\:mm";
                dataGridView1.Columns[6].DefaultCellStyle.Format = "HH\\:mm";
                //dataGridView1.Rows[1].Cells["KALKIS_SAATI"].Value = Convert.ToDateTime(dataGridView1.Rows[1].Cells["KALKIS_SAATI"].Value).ToString("hh:mm");
                baglanti.Close();
            }
        }

        void listele_gelen()
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "select * FROM table_pid WHERE VARIS_YERI='KONYA   ' and VARIS_SAATI between CONVERT(Varchar(8), GETDATE()-'00:30:00', 108) and '23:59:59' ORDER BY VARIS_SAATI ASC";
                SqlDataAdapter adpr = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adpr.Fill(ds, "table_pid");
                dataGridView1.DataSource = ds.Tables["table_pid"];
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[5].DefaultCellStyle.Format = "HH\\:mm";
                dataGridView1.Columns[6].DefaultCellStyle.Format = "HH\\:mm";
                //dataGridView1.Rows[1].Cells["KALKIS_SAATI"].Value = Convert.ToDateTime(dataGridView1.Rows[1].Cells["KALKIS_SAATI"].Value).ToString("hh:mm");
                baglanti.Close();
            }
        }

        void sefer_listele()
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "select * FROM table_pid ORDER BY KALKIS_SAATI ASC";
                SqlDataAdapter adpr = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adpr.Fill(ds, "table_pid");
                dataGridView2.DataSource = ds.Tables["table_pid"];
                dataGridView2.Columns[0].Visible = false;
                dataGridView2.Columns[5].DefaultCellStyle.Format = "HH\\:mm";
                dataGridView2.Columns[6].DefaultCellStyle.Format = "HH\\:mm";
                baglanti.Close();
            }
        }

        void tarih_gonder()
        {
            client.WriteLineAndGetReply("{A00C1X001Y000W100H100O004T" + DateTime.Today.ToShortDateString() + "    }", TimeSpan.FromSeconds(1));
            client.WriteLineAndGetReply("{A00C1X097Y000W100H100O004T" + DateTime.Today.ToShortDateString() + "    }", TimeSpan.FromSeconds(1));           
        }

        void buyuk_tarih_gonder()
        {
            client.WriteLineAndGetReply("{A01C1X096Y000W100H100O004T" + DateTime.Today.ToShortDateString() + "  }", TimeSpan.FromSeconds(1));

        }

        void saat_gonder()
        {

            if (chbbuyukekran.Checked == true)
            {
                try
                {
                    
                    client.Connect("10.200.215.80", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A01C4X192Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbbuyukekran.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 1 Karaman Yönü Bağlantı Hatası");
                    chbbuyukekran.ForeColor = Color.Red;
                }
            }

            if (chbp1kar.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.83", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A00C4X065Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbp1kar.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 1 Karaman Yönü Bağlantı Hatası");
                    chbp1kar.ForeColor = Color.Red;
                }
            }

            if (chbp1ankara.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.81", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A00C4X065Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbp1ankara.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 1 Ankara Yönü Bağlantı Hatası");
                    chbp1ankara.ForeColor = Color.Red;
                }
            }

            if (chbp2karaman.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.85", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A00C4X065Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbp2karaman.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 2 Karaman Yönü Bağlantı Hatası");
                    chbp2karaman.ForeColor = Color.Red;
                }
            }

            if (chbp2ankara.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.84", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A00C4X065Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbp2ankara.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 2 Ankara Yönü Bağlantı Hatası");
                    chbp2ankara.ForeColor = Color.Red;
                }
            }

            if (chbperon3.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.86", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A00C4X065Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbperon3.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 3 Bağlantı Hatası");
                    chbperon3.ForeColor = Color.Red;
                }
            }

            if (chbaltgecit.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.82", Convert.ToInt32("4001"));
                    client.WriteLineAndGetReply("{A00C4X065Y000W100H100O004T" + DateTime.Now.ToString("HH:mm:ss") + "}", TimeSpan.FromSeconds(0.1));
                    client.Disconnect();
                    chbaltgecit.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Altgeçit Bağlantı Hatası");
                    chbaltgecit.ForeColor = Color.Red;
                }
            }

        }

        void buyukekrana_gonder()

        {
            try
            {
                client.WriteLineAndGetReply("{A00C1X144Y000W100H100O004T" + "GIDEN TREN " + "}", TimeSpan.FromSeconds(1));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A00C1X000Y020W100H100O000T" + "TREN ADI "+ "VARIS Y " + "KALKIS " + "VARIS " + "ACKLMA" + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A01C1X000Y016W100H100O000T" + dataGridView1.Rows[0].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[0].Cells[4].Value.ToString() + dataGridView1.Rows[0].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[0].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[0].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A01C1X000Y032W100H100O000T" + dataGridView1.Rows[1].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[1].Cells[4].Value.ToString() + dataGridView1.Rows[1].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[1].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[1].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }

            catch (Exception)
            {

            }

            try
            {
                client.WriteLineAndGetReply("{A02C1X000Y000W100H100O000T" + dataGridView1.Rows[2].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[2].Cells[4].Value.ToString() + dataGridView1.Rows[2].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[2].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[2].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }

            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A02C1X000Y016W100H100O000T" + dataGridView1.Rows[3].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[3].Cells[4].Value.ToString() + dataGridView1.Rows[3].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[3].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[3].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A02C1X000Y032W100H100O000T" + dataGridView1.Rows[4].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[4].Cells[4].Value.ToString() + dataGridView1.Rows[4].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[4].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[4].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A03C1X000Y000W100H100O000T" + dataGridView1.Rows[5].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[5].Cells[4].Value.ToString() + dataGridView1.Rows[5].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[5].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[5].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A03C1X000Y016W100H100O000T" + dataGridView1.Rows[6].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[6].Cells[4].Value.ToString() + dataGridView1.Rows[6].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[6].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[6].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A03C1X000Y032W100H100O000T" + dataGridView1.Rows[7].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[7].Cells[4].Value.ToString() + dataGridView1.Rows[7].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[7].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[7].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A04C1X000Y000W100H100O000T" + dataGridView1.Rows[8].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[8].Cells[4].Value.ToString() + dataGridView1.Rows[8].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[8].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[8].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A04C1X000Y032W100H100O004T" +"     TCDD IYI YOLCULUKLAR DILER" + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
        }

        void buyukekrana_gonder_gelen()

        {
            try
            {
                client.WriteLineAndGetReply("{A00C1X144Y000W100H100O004T" + "GELEN TREN " + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A00C1X000Y020W100H100O000T" + "TREN ADI " + "KALKS Y " + "KALKIS " + "VARIS " + "ACKLMA" + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A01C1X000Y016W100H100O000T" + dataGridView1.Rows[0].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[0].Cells[3].Value.ToString() + dataGridView1.Rows[0].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[0].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[0].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A01C1X000Y032W100H100O000T" + dataGridView1.Rows[1].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[1].Cells[3].Value.ToString() + dataGridView1.Rows[1].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[1].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[1].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }

            catch (Exception)
            {

            }

            try
            {
                client.WriteLineAndGetReply("{A02C1X000Y000W100H100O000T" + dataGridView1.Rows[2].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[2].Cells[3].Value.ToString() + dataGridView1.Rows[2].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[2].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[2].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }

            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A02C1X000Y016W100H100O000T" + dataGridView1.Rows[3].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[3].Cells[3].Value.ToString() + dataGridView1.Rows[3].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[3].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[3].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A02C1X000Y032W100H100O000T" + dataGridView1.Rows[4].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[4].Cells[3].Value.ToString() + dataGridView1.Rows[4].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[4].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[4].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A03C1X000Y000W100H100O000T" + dataGridView1.Rows[5].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[5].Cells[3].Value.ToString() + dataGridView1.Rows[5].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[5].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[5].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A03C1X000Y016W100H100O000T" + dataGridView1.Rows[6].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[6].Cells[3].Value.ToString() + dataGridView1.Rows[6].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[6].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[6].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A03C1X000Y032W100H100O000T" + dataGridView1.Rows[7].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[7].Cells[3].Value.ToString() + dataGridView1.Rows[7].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[7].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[7].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A04C1X000Y000W100H100O000T" + dataGridView1.Rows[8].Cells[1].Value.ToString().Substring(0, 9) + " " + dataGridView1.Rows[8].Cells[3].Value.ToString() + dataGridView1.Rows[8].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[8].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[8].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A04C1X000Y032W100H100O004T" + "     TCDD IYI YOLCULUKLAR DILER" + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
        }

        void kucukekrana_gonder()
        {
            try
            { 
                client.WriteLineAndGetReply("{A00C1X000Y016W100H100O000T" + dataGridView1.Rows[0].Cells[1].Value.ToString().Substring(0, 3) + " " + dataGridView1.Rows[0].Cells[4].Value.ToString() + dataGridView1.Rows[0].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[0].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[0].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {
             
            }
            try
            { 
                client.WriteLineAndGetReply("{A00C1X000Y024W100H100O000T" + dataGridView1.Rows[1].Cells[1].Value.ToString().Substring(0, 3) + " " + dataGridView1.Rows[1].Cells[4].Value.ToString() + dataGridView1.Rows[1].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[1].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[1].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }

            catch (Exception)
            {

            }

            try
            {
                client.WriteLineAndGetReply("{A00C1X000Y032W100H100O000T" + dataGridView1.Rows[2].Cells[1].Value.ToString().Substring(0, 3) + " " + dataGridView1.Rows[2].Cells[4].Value.ToString() + dataGridView1.Rows[2].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[2].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[2].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }

            catch (Exception)
            {

            }
            try
            {
                client.WriteLineAndGetReply("{A00C1X000Y040W100H100O000T" + dataGridView1.Rows[3].Cells[1].Value.ToString().Substring(0, 3) + " " + dataGridView1.Rows[3].Cells[4].Value.ToString() + dataGridView1.Rows[3].Cells[5].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[3].Cells[6].Value.ToString().Substring(10, 5) + " " + dataGridView1.Rows[3].Cells[7].Value.ToString() + "}", TimeSpan.FromSeconds(2));
            }
            catch (Exception)
            {

            }
            //client.Disconnect();
        }

        void kucukekrani_temizle()
        {
            client.WriteLineAndGetReply("{A00C1X000Y016W100H100O000T                                                          }", TimeSpan.FromSeconds(2)) ;
            client.WriteLineAndGetReply("{A00C1X000Y024W100H100O000T                                                          }", TimeSpan.FromSeconds(2)) ;
            client.WriteLineAndGetReply("{A00C1X000Y032W100H100O000T                                                          }", TimeSpan.FromSeconds(2)) ;
            client.WriteLineAndGetReply("{A00C1X000Y040W100H100O000T                                                          }", TimeSpan.FromSeconds(2)) ;
            //client.Disconnect();
        }

        void buyukekrani_temizle()
        {
            client.WriteLineAndGetReply("{A01C1X000Y016W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A01C1X000Y032W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A02C1X000Y000W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A02C1X000Y016W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A02C1X000Y032W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A03C1X000Y000W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A03C1X000Y016W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A03C1X000Y032W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A04C1X000Y000W100H100O000T                                                          }", TimeSpan.FromSeconds(2));
            client.WriteLineAndGetReply("{A04C1X000Y032W100H100O004T                                                          }", TimeSpan.FromSeconds(2));

        }

        private void btngonder_Click(object sender, EventArgs e)
        {
            label8.Text = "Bilgi Gönderiliyor...";
            label8.ForeColor = Color.Red;
            saat_gonder();
            if (chbbuyukekran.Checked == true)
            {
                try
                {
                    if (deg == 1)
                    {
                        client.Connect("10.200.215.80", Convert.ToInt32("4001"));
                        listele();
                        buyuk_tarih_gonder();
                        buyukekrani_temizle();
                        buyukekrana_gonder();
                        client.Disconnect();
                        deg = 2;
                    }
                    else
                    {
                        client.Connect("10.200.215.80", Convert.ToInt32("4001"));
                        listele_gelen();
                        buyuk_tarih_gonder();
                        buyukekrani_temizle();
                        buyukekrana_gonder_gelen();
                        client.Disconnect();
                        deg = 1;
                    }
                    chbbuyukekran.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 1 Karaman Yönü Bağlantı Hatası");
                    chbbuyukekran.ForeColor = Color.Red;
                }
            }

            if (chbp1kar.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.83", Convert.ToInt32("4001"));
                    listele();
                    tarih_gonder();
                    kucukekrani_temizle();
                    kucukekrana_gonder();
                    client.Disconnect();
                    chbp1kar.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 1 Karaman Yönü Bağlantı Hatası");
                    chbp1kar.ForeColor = Color.Red;
                }
            }

            if (chbp1ankara.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.81", Convert.ToInt32("4001"));
                    listele();
                    tarih_gonder();
                    kucukekrani_temizle();
                    kucukekrana_gonder();
                    client.Disconnect();
                    chbp1ankara.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 1 Ankara Yönü Bağlantı Hatası");
                    chbp1ankara.ForeColor = Color.Red;
                }
            }

            if (chbp2karaman.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.85", Convert.ToInt32("4001"));
                    listele();
                    tarih_gonder();
                    kucukekrani_temizle();
                    kucukekrana_gonder();
                    client.Disconnect();
                    chbp2karaman.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 2 Karaman Yönü Bağlantı Hatası");
                    chbp2karaman.ForeColor = Color.Red;
                }
            }

            if (chbp2ankara.Checked== true)
            {
                try
                {
                    client.Connect("10.200.215.84", Convert.ToInt32("4001"));
                    listele();
                    tarih_gonder();
                    kucukekrani_temizle();
                    kucukekrana_gonder();
                    client.Disconnect();
                    chbp2ankara.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 2 Ankara Yönü Bağlantı Hatası");
                    chbp2ankara.ForeColor = Color.Red;
                }            
            }

            if (chbperon3.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.86", Convert.ToInt32("4001"));
                    listele();
                    tarih_gonder();
                    kucukekrani_temizle();
                    kucukekrana_gonder();
                    client.Disconnect();
                    chbperon3.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Peron 3 Bağlantı Hatası");
                    chbperon3.ForeColor = Color.Red;
                }               
            }

            if (chbaltgecit.Checked == true)
            {
                try
                {
                    client.Connect("10.200.215.82", Convert.ToInt32("4001"));
                    listele();
                    tarih_gonder();
                    kucukekrani_temizle();
                    kucukekrana_gonder();
                    client.Disconnect();
                    chbaltgecit.ForeColor = Color.Black;
                }
                catch (Exception)
                {
                    //MessageBox.Show("Altgeçit Bağlantı Hatası");
                    chbaltgecit.ForeColor = Color.Red;
                }             
            }


            label8.Text = "Bilgi Gönderimi Tamamlandı";
            label8.ForeColor = Color.Black;
        }

        //DateTime time1;
        private void button1_Click(object sender, EventArgs e)
        {
            client.Connect("10.200.215.83", Convert.ToInt32("4001"));
            kucukekrani_temizle();
        }



        private void button1_Click_1(object sender, EventArgs e)
        {

            //Timespan fark = dataGridView1.Rows[0].Cells[4].Value-DateTime.Now.TimeOfDay);
            //TimeSpan fark = Convert.ToDateTime(dataGridView1.Rows[0].Cells[4].Value) - DateTime.Now.TimeOfDay;
            String suan = DateTime.Now.ToShortTimeString();
            String bitis = dataGridView1.Rows[0].Cells[5].Value.ToString();
            TimeSpan fark = Convert.ToDateTime(suan) - Convert.ToDateTime(bitis);
 
        }

        private void btnlistele_Click(object sender, EventArgs e)
        {
            listele();
        }

        private void btnsefer_Click(object sender, EventArgs e)
        {
            sefer_listele();
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "INSERT INTO table_pid (TREN_ADI,SEFER_NO,KALKIS_YERI,VARIS_YERI,KALKIS_SAATI,VARIS_SAATI,ACIKLAMA) VALUES ('" + cbtrenadi.Text + "','" + cbseferno.Text + "','" + cbkalkisyeri.Text + "','" + cbvarisyeri.Text + "','" + dtkalkissaati.Value.ToShortTimeString() + "','" + dtvarissaati.Value.ToShortTimeString() + "','" + tbaciklama.Text + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();               
                baglanti.Close();
                sefer_listele();
                MessageBox.Show("Ekleme Başarılı");

            }
        }

        private void btnduzenle_Click(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "UPDATE table_pid SET TREN_ADI='" + cbtrenadi.Text + "',SEFER_NO='" + cbseferno.Text + "',KALKIS_YERI='" + cbkalkisyeri.Text + "',VARIS_YERI='" + cbvarisyeri.Text + "',KALKIS_SAATI='" + dtkalkissaati.Value.ToShortTimeString() + "',VARIS_SAATI='" + dtvarissaati.Value.ToShortTimeString() + "',ACIKLAMA='" + tbaciklama.Text + "' WHERE id=@numara";
                cmd.Parameters.AddWithValue("@numara", dataGridView2.CurrentRow.Cells[0].Value.ToString());
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                baglanti.Close();
                sefer_listele();
                MessageBox.Show("Düzenleme Başarılı");

            }
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Seçili Öğeyi silmek istiyor musunuz?", "DİKKAT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = baglanti;
                    cmd.CommandText = "DELETE FROM table_pid WHERE id=@numara";
                    cmd.Parameters.AddWithValue("@numara", dataGridView2.CurrentRow.Cells[0].Value.ToString());
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    baglanti.Close();
                    sefer_listele();
                    MessageBox.Show("Silme Başarılı");

                }
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cbtrenadi.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            cbseferno.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            cbkalkisyeri.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
            cbvarisyeri.Text = dataGridView2.CurrentRow.Cells[4].Value.ToString();
            dtkalkissaati.Text = dataGridView2.CurrentRow.Cells[5].Value.ToString();
            dtvarissaati.Text = dataGridView2.CurrentRow.Cells[6].Value.ToString();
            tbaciklama.Text = dataGridView2.CurrentRow.Cells[7].Value.ToString();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabControl1.TabPages["tabPage2"])//your specific tabname
            {
                timer1.Stop();
            }
            if (tabControl1.SelectedTab == tabControl1.TabPages["tabPage1"])//your specific tabname
            {
                timer1.Start();
            }
        }

        private void btnsaat_Click(object sender, EventArgs e)
        {
            saat_gonder();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            if (MessageBox.Show("Programı Kapatmak İstiyor Musunuz ? Dikkat: Programı kapatmanız halinde panolara bilgi gönderimi durdurulacaktır!!!", "Dikkat",MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
            }
        }
    }
}
