﻿namespace pid_deneme1
{
    partial class frmmain
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmmain));
            this.pid_serverDataSet = new pid_deneme1.pid_serverDataSet();
            this.pidserverDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tablepidBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.table_pidTableAdapter = new pid_deneme1.pid_serverDataSetTableAdapters.table_pidTableAdapter();
            this.pid_serverDataSet1 = new pid_deneme1.pid_serverDataSet1();
            this.pidserverDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnsaat = new System.Windows.Forms.Button();
            this.btnlistele = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tRENADIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sEFERNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kALKISYERIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vARISYERIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kALKISSAATIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vARISSAATIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aCIKLAMADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablepidBindingSource8 = new System.Windows.Forms.BindingSource(this.components);
            this.btntemizle = new System.Windows.Forms.Button();
            this.btngonder = new System.Windows.Forms.Button();
            this.chbbuyukekran = new System.Windows.Forms.CheckBox();
            this.chbperon3 = new System.Windows.Forms.CheckBox();
            this.chbp1kar = new System.Windows.Forms.CheckBox();
            this.chbp2ankara = new System.Windows.Forms.CheckBox();
            this.chbp1ankara = new System.Windows.Forms.CheckBox();
            this.chbaltgecit = new System.Windows.Forms.CheckBox();
            this.chbp2karaman = new System.Windows.Forms.CheckBox();
            this.tablepidBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tablepidBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.pidserverDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pid_serverDataSet2 = new pid_deneme1.pid_serverDataSet2();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblseferno = new System.Windows.Forms.Label();
            this.cbseferno = new System.Windows.Forms.ComboBox();
            this.btnara = new System.Windows.Forms.Button();
            this.btnsefer = new System.Windows.Forms.Button();
            this.dtvarissaati = new System.Windows.Forms.DateTimePicker();
            this.cbtrenadi = new System.Windows.Forms.ComboBox();
            this.dtkalkissaati = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cbvarisyeri = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbkalkisyeri = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbaciklama = new System.Windows.Forms.TextBox();
            this.btnekle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnduzenle = new System.Windows.Forms.Button();
            this.btnsil = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablepidBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tablepidBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.pid_serverDataSet3 = new pid_deneme1.pid_serverDataSet3();
            this.tablepidBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.table_pidTableAdapter1 = new pid_deneme1.pid_serverDataSet3TableAdapters.table_pidTableAdapter();
            this.tablepidBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.table_pidTableAdapter2 = new pid_deneme1.pid_serverDataSet2TableAdapters.table_pidTableAdapter();
            this.tablepidBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.pidserverDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSet1BindingSource)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSetBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // pid_serverDataSet
            // 
            this.pid_serverDataSet.DataSetName = "pid_serverDataSet";
            this.pid_serverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pidserverDataSetBindingSource
            // 
            this.pidserverDataSetBindingSource.DataSource = this.pid_serverDataSet;
            this.pidserverDataSetBindingSource.Position = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.btngonder_Click);
            // 
            // tablepidBindingSource
            // 
            this.tablepidBindingSource.DataMember = "table_pid";
            this.tablepidBindingSource.DataSource = this.pidserverDataSetBindingSource;
            // 
            // table_pidTableAdapter
            // 
            this.table_pidTableAdapter.ClearBeforeFill = true;
            // 
            // pid_serverDataSet1
            // 
            this.pid_serverDataSet1.DataSetName = "pid_serverDataSet1";
            this.pid_serverDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pidserverDataSet1BindingSource
            // 
            this.pidserverDataSet1BindingSource.DataSource = this.pid_serverDataSet1;
            this.pidserverDataSet1BindingSource.Position = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.btnsaat);
            this.tabPage1.Controls.Add(this.btnlistele);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.btntemizle);
            this.tabPage1.Controls.Add(this.btngonder);
            this.tabPage1.Controls.Add(this.chbbuyukekran);
            this.tabPage1.Controls.Add(this.chbperon3);
            this.tabPage1.Controls.Add(this.chbp1kar);
            this.tabPage1.Controls.Add(this.chbp2ankara);
            this.tabPage1.Controls.Add(this.chbp1ankara);
            this.tabPage1.Controls.Add(this.chbaltgecit);
            this.tabPage1.Controls.Add(this.chbp2karaman);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnsaat
            // 
            resources.ApplyResources(this.btnsaat, "btnsaat");
            this.btnsaat.Name = "btnsaat";
            this.btnsaat.UseVisualStyleBackColor = true;
            this.btnsaat.Click += new System.EventHandler(this.btnsaat_Click);
            // 
            // btnlistele
            // 
            resources.ApplyResources(this.btnlistele, "btnlistele");
            this.btnlistele.Name = "btnlistele";
            this.btnlistele.UseVisualStyleBackColor = true;
            this.btnlistele.Click += new System.EventHandler(this.btnlistele_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridView1);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.tRENADIDataGridViewTextBoxColumn,
            this.sEFERNODataGridViewTextBoxColumn,
            this.kALKISYERIDataGridViewTextBoxColumn,
            this.vARISYERIDataGridViewTextBoxColumn,
            this.kALKISSAATIDataGridViewTextBoxColumn,
            this.vARISSAATIDataGridViewTextBoxColumn,
            this.aCIKLAMADataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tablepidBindingSource8;
            resources.ApplyResources(this.dataGridView1, "dataGridView1");
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            resources.ApplyResources(this.idDataGridViewTextBoxColumn, "idDataGridViewTextBoxColumn");
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tRENADIDataGridViewTextBoxColumn
            // 
            this.tRENADIDataGridViewTextBoxColumn.DataPropertyName = "TREN_ADI";
            resources.ApplyResources(this.tRENADIDataGridViewTextBoxColumn, "tRENADIDataGridViewTextBoxColumn");
            this.tRENADIDataGridViewTextBoxColumn.Name = "tRENADIDataGridViewTextBoxColumn";
            this.tRENADIDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sEFERNODataGridViewTextBoxColumn
            // 
            this.sEFERNODataGridViewTextBoxColumn.DataPropertyName = "SEFER_NO";
            resources.ApplyResources(this.sEFERNODataGridViewTextBoxColumn, "sEFERNODataGridViewTextBoxColumn");
            this.sEFERNODataGridViewTextBoxColumn.Name = "sEFERNODataGridViewTextBoxColumn";
            this.sEFERNODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kALKISYERIDataGridViewTextBoxColumn
            // 
            this.kALKISYERIDataGridViewTextBoxColumn.DataPropertyName = "KALKIS_YERI";
            resources.ApplyResources(this.kALKISYERIDataGridViewTextBoxColumn, "kALKISYERIDataGridViewTextBoxColumn");
            this.kALKISYERIDataGridViewTextBoxColumn.Name = "kALKISYERIDataGridViewTextBoxColumn";
            this.kALKISYERIDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vARISYERIDataGridViewTextBoxColumn
            // 
            this.vARISYERIDataGridViewTextBoxColumn.DataPropertyName = "VARIS_YERI";
            resources.ApplyResources(this.vARISYERIDataGridViewTextBoxColumn, "vARISYERIDataGridViewTextBoxColumn");
            this.vARISYERIDataGridViewTextBoxColumn.Name = "vARISYERIDataGridViewTextBoxColumn";
            this.vARISYERIDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kALKISSAATIDataGridViewTextBoxColumn
            // 
            this.kALKISSAATIDataGridViewTextBoxColumn.DataPropertyName = "KALKIS_SAATI";
            resources.ApplyResources(this.kALKISSAATIDataGridViewTextBoxColumn, "kALKISSAATIDataGridViewTextBoxColumn");
            this.kALKISSAATIDataGridViewTextBoxColumn.Name = "kALKISSAATIDataGridViewTextBoxColumn";
            this.kALKISSAATIDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vARISSAATIDataGridViewTextBoxColumn
            // 
            this.vARISSAATIDataGridViewTextBoxColumn.DataPropertyName = "VARIS_SAATI";
            resources.ApplyResources(this.vARISSAATIDataGridViewTextBoxColumn, "vARISSAATIDataGridViewTextBoxColumn");
            this.vARISSAATIDataGridViewTextBoxColumn.Name = "vARISSAATIDataGridViewTextBoxColumn";
            this.vARISSAATIDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // aCIKLAMADataGridViewTextBoxColumn
            // 
            this.aCIKLAMADataGridViewTextBoxColumn.DataPropertyName = "ACIKLAMA";
            resources.ApplyResources(this.aCIKLAMADataGridViewTextBoxColumn, "aCIKLAMADataGridViewTextBoxColumn");
            this.aCIKLAMADataGridViewTextBoxColumn.Name = "aCIKLAMADataGridViewTextBoxColumn";
            this.aCIKLAMADataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tablepidBindingSource8
            // 
            this.tablepidBindingSource8.DataMember = "table_pid";
            this.tablepidBindingSource8.DataSource = this.pidserverDataSetBindingSource;
            // 
            // btntemizle
            // 
            resources.ApplyResources(this.btntemizle, "btntemizle");
            this.btntemizle.Name = "btntemizle";
            this.btntemizle.UseVisualStyleBackColor = true;
            this.btntemizle.Click += new System.EventHandler(this.button1_Click);
            // 
            // btngonder
            // 
            resources.ApplyResources(this.btngonder, "btngonder");
            this.btngonder.Name = "btngonder";
            this.btngonder.UseVisualStyleBackColor = true;
            this.btngonder.Click += new System.EventHandler(this.btngonder_Click);
            // 
            // chbbuyukekran
            // 
            resources.ApplyResources(this.chbbuyukekran, "chbbuyukekran");
            this.chbbuyukekran.Name = "chbbuyukekran";
            this.chbbuyukekran.UseVisualStyleBackColor = true;
            // 
            // chbperon3
            // 
            resources.ApplyResources(this.chbperon3, "chbperon3");
            this.chbperon3.Name = "chbperon3";
            this.chbperon3.UseVisualStyleBackColor = true;
            // 
            // chbp1kar
            // 
            this.chbp1kar.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            resources.ApplyResources(this.chbp1kar, "chbp1kar");
            this.chbp1kar.Name = "chbp1kar";
            this.chbp1kar.UseVisualStyleBackColor = true;
            // 
            // chbp2ankara
            // 
            resources.ApplyResources(this.chbp2ankara, "chbp2ankara");
            this.chbp2ankara.Name = "chbp2ankara";
            this.chbp2ankara.UseVisualStyleBackColor = true;
            // 
            // chbp1ankara
            // 
            resources.ApplyResources(this.chbp1ankara, "chbp1ankara");
            this.chbp1ankara.Name = "chbp1ankara";
            this.chbp1ankara.UseVisualStyleBackColor = true;
            // 
            // chbaltgecit
            // 
            resources.ApplyResources(this.chbaltgecit, "chbaltgecit");
            this.chbaltgecit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chbaltgecit.Name = "chbaltgecit";
            this.chbaltgecit.UseVisualStyleBackColor = true;
            // 
            // chbp2karaman
            // 
            resources.ApplyResources(this.chbp2karaman, "chbp2karaman");
            this.chbp2karaman.Name = "chbp2karaman";
            this.chbp2karaman.UseVisualStyleBackColor = true;
            // 
            // tablepidBindingSource2
            // 
            this.tablepidBindingSource2.DataMember = "table_pid";
            this.tablepidBindingSource2.DataSource = this.pidserverDataSetBindingSource;
            // 
            // tablepidBindingSource6
            // 
            this.tablepidBindingSource6.DataMember = "table_pid";
            this.tablepidBindingSource6.DataSource = this.pidserverDataSet2BindingSource;
            // 
            // pidserverDataSet2BindingSource
            // 
            this.pidserverDataSet2BindingSource.DataSource = this.pid_serverDataSet2;
            this.pidserverDataSet2BindingSource.Position = 0;
            // 
            // pid_serverDataSet2
            // 
            this.pid_serverDataSet2.DataSetName = "pid_serverDataSet2";
            this.pid_serverDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblseferno);
            this.tabPage2.Controls.Add(this.cbseferno);
            this.tabPage2.Controls.Add(this.btnara);
            this.tabPage2.Controls.Add(this.btnsefer);
            this.tabPage2.Controls.Add(this.dtvarissaati);
            this.tabPage2.Controls.Add(this.cbtrenadi);
            this.tabPage2.Controls.Add(this.dtkalkissaati);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.cbvarisyeri);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.cbkalkisyeri);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.tbaciklama);
            this.tabPage2.Controls.Add(this.btnekle);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btnduzenle);
            this.tabPage2.Controls.Add(this.btnsil);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.dataGridView2);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblseferno
            // 
            resources.ApplyResources(this.lblseferno, "lblseferno");
            this.lblseferno.Name = "lblseferno";
            // 
            // cbseferno
            // 
            this.cbseferno.FormattingEnabled = true;
            resources.ApplyResources(this.cbseferno, "cbseferno");
            this.cbseferno.Name = "cbseferno";
            // 
            // btnara
            // 
            resources.ApplyResources(this.btnara, "btnara");
            this.btnara.Name = "btnara";
            this.btnara.UseVisualStyleBackColor = true;
            // 
            // btnsefer
            // 
            resources.ApplyResources(this.btnsefer, "btnsefer");
            this.btnsefer.Name = "btnsefer";
            this.btnsefer.UseVisualStyleBackColor = true;
            this.btnsefer.Click += new System.EventHandler(this.btnsefer_Click);
            // 
            // dtvarissaati
            // 
            resources.ApplyResources(this.dtvarissaati, "dtvarissaati");
            this.dtvarissaati.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtvarissaati.Name = "dtvarissaati";
            // 
            // cbtrenadi
            // 
            this.cbtrenadi.FormattingEnabled = true;
            resources.ApplyResources(this.cbtrenadi, "cbtrenadi");
            this.cbtrenadi.Name = "cbtrenadi";
            // 
            // dtkalkissaati
            // 
            resources.ApplyResources(this.dtkalkissaati, "dtkalkissaati");
            this.dtkalkissaati.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtkalkissaati.Name = "dtkalkissaati";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // cbvarisyeri
            // 
            this.cbvarisyeri.FormattingEnabled = true;
            this.cbvarisyeri.Items.AddRange(new object[] {
            resources.GetString("cbvarisyeri.Items"),
            resources.GetString("cbvarisyeri.Items1"),
            resources.GetString("cbvarisyeri.Items2"),
            resources.GetString("cbvarisyeri.Items3"),
            resources.GetString("cbvarisyeri.Items4"),
            resources.GetString("cbvarisyeri.Items5"),
            resources.GetString("cbvarisyeri.Items6"),
            resources.GetString("cbvarisyeri.Items7"),
            resources.GetString("cbvarisyeri.Items8"),
            resources.GetString("cbvarisyeri.Items9"),
            resources.GetString("cbvarisyeri.Items10"),
            resources.GetString("cbvarisyeri.Items11"),
            resources.GetString("cbvarisyeri.Items12")});
            resources.ApplyResources(this.cbvarisyeri, "cbvarisyeri");
            this.cbvarisyeri.Name = "cbvarisyeri";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // cbkalkisyeri
            // 
            this.cbkalkisyeri.FormattingEnabled = true;
            this.cbkalkisyeri.Items.AddRange(new object[] {
            resources.GetString("cbkalkisyeri.Items"),
            resources.GetString("cbkalkisyeri.Items1"),
            resources.GetString("cbkalkisyeri.Items2"),
            resources.GetString("cbkalkisyeri.Items3"),
            resources.GetString("cbkalkisyeri.Items4"),
            resources.GetString("cbkalkisyeri.Items5"),
            resources.GetString("cbkalkisyeri.Items6"),
            resources.GetString("cbkalkisyeri.Items7"),
            resources.GetString("cbkalkisyeri.Items8"),
            resources.GetString("cbkalkisyeri.Items9"),
            resources.GetString("cbkalkisyeri.Items10"),
            resources.GetString("cbkalkisyeri.Items11"),
            resources.GetString("cbkalkisyeri.Items12")});
            resources.ApplyResources(this.cbkalkisyeri, "cbkalkisyeri");
            this.cbkalkisyeri.Name = "cbkalkisyeri";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // tbaciklama
            // 
            resources.ApplyResources(this.tbaciklama, "tbaciklama");
            this.tbaciklama.Name = "tbaciklama";
            // 
            // btnekle
            // 
            resources.ApplyResources(this.btnekle, "btnekle");
            this.btnekle.Name = "btnekle";
            this.btnekle.UseVisualStyleBackColor = true;
            this.btnekle.Click += new System.EventHandler(this.btnekle_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // btnduzenle
            // 
            resources.ApplyResources(this.btnduzenle, "btnduzenle");
            this.btnduzenle.Name = "btnduzenle";
            this.btnduzenle.UseVisualStyleBackColor = true;
            this.btnduzenle.Click += new System.EventHandler(this.btnduzenle_Click);
            // 
            // btnsil
            // 
            resources.ApplyResources(this.btnsil, "btnsil");
            this.btnsil.Name = "btnsil";
            this.btnsil.UseVisualStyleBackColor = true;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dataGridView2.DataSource = this.tablepidBindingSource2;
            resources.ApplyResources(this.dataGridView2, "dataGridView2");
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "id";
            resources.ApplyResources(this.Column1, "Column1");
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "TREN_ADI";
            resources.ApplyResources(this.dataGridViewTextBoxColumn1, "dataGridViewTextBoxColumn1");
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "SEFER_NO";
            resources.ApplyResources(this.dataGridViewTextBoxColumn2, "dataGridViewTextBoxColumn2");
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "KALKIS_YERI";
            resources.ApplyResources(this.dataGridViewTextBoxColumn3, "dataGridViewTextBoxColumn3");
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "VARIS_YERI";
            resources.ApplyResources(this.dataGridViewTextBoxColumn4, "dataGridViewTextBoxColumn4");
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "KALKIS_SAATI";
            resources.ApplyResources(this.dataGridViewTextBoxColumn5, "dataGridViewTextBoxColumn5");
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "VARIS_SAATI";
            resources.ApplyResources(this.dataGridViewTextBoxColumn6, "dataGridViewTextBoxColumn6");
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ACIKLAMA";
            resources.ApplyResources(this.dataGridViewTextBoxColumn7, "dataGridViewTextBoxColumn7");
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // tablepidBindingSource1
            // 
            this.tablepidBindingSource1.DataMember = "table_pid";
            this.tablepidBindingSource1.DataSource = this.pidserverDataSetBindingSource;
            // 
            // tablepidBindingSource3
            // 
            this.tablepidBindingSource3.DataMember = "table_pid";
            this.tablepidBindingSource3.DataSource = this.pidserverDataSetBindingSource;
            // 
            // pid_serverDataSet3
            // 
            this.pid_serverDataSet3.DataSetName = "pid_serverDataSet3";
            this.pid_serverDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tablepidBindingSource4
            // 
            this.tablepidBindingSource4.DataMember = "table_pid";
            this.tablepidBindingSource4.DataSource = this.pid_serverDataSet3;
            // 
            // table_pidTableAdapter1
            // 
            this.table_pidTableAdapter1.ClearBeforeFill = true;
            // 
            // tablepidBindingSource5
            // 
            this.tablepidBindingSource5.DataMember = "table_pid";
            this.tablepidBindingSource5.DataSource = this.pidserverDataSetBindingSource;
            // 
            // table_pidTableAdapter2
            // 
            this.table_pidTableAdapter2.ClearBeforeFill = true;
            // 
            // tablepidBindingSource7
            // 
            this.tablepidBindingSource7.DataMember = "table_pid";
            this.tablepidBindingSource7.DataSource = this.pidserverDataSetBindingSource;
            // 
            // pidserverDataSetBindingSource1
            // 
            this.pidserverDataSetBindingSource1.DataSource = this.pid_serverDataSet;
            this.pidserverDataSetBindingSource1.Position = 0;
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // frmmain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.Name = "frmmain";
            this.Load += new System.EventHandler(this.frmmain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSet1BindingSource)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSetBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource pidserverDataSetBindingSource;
        private pid_serverDataSet pid_serverDataSet;
        private System.Windows.Forms.BindingSource tablepidBindingSource;
        private pid_serverDataSetTableAdapters.table_pidTableAdapter table_pidTableAdapter;
        private pid_serverDataSet1 pid_serverDataSet1;
        private System.Windows.Forms.BindingSource pidserverDataSet1BindingSource;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btntemizle;
        private System.Windows.Forms.Button btngonder;
        private System.Windows.Forms.CheckBox chbbuyukekran;
        private System.Windows.Forms.CheckBox chbperon3;
        private System.Windows.Forms.CheckBox chbp1kar;
        private System.Windows.Forms.CheckBox chbp2ankara;
        private System.Windows.Forms.CheckBox chbp1ankara;
        private System.Windows.Forms.CheckBox chbaltgecit;
        private System.Windows.Forms.CheckBox chbp2karaman;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.BindingSource tablepidBindingSource3;
        private System.Windows.Forms.BindingSource tablepidBindingSource1;
        private System.Windows.Forms.BindingSource tablepidBindingSource2;
        private pid_serverDataSet3 pid_serverDataSet3;
        private System.Windows.Forms.BindingSource tablepidBindingSource4;
        private pid_serverDataSet3TableAdapters.table_pidTableAdapter table_pidTableAdapter1;
        private System.Windows.Forms.BindingSource pidserverDataSet2BindingSource;
        private pid_serverDataSet2 pid_serverDataSet2;
        private System.Windows.Forms.BindingSource tablepidBindingSource5;
        private System.Windows.Forms.BindingSource tablepidBindingSource6;
        private pid_serverDataSet2TableAdapters.table_pidTableAdapter table_pidTableAdapter2;
        private System.Windows.Forms.BindingSource tablepidBindingSource7;
        private System.Windows.Forms.BindingSource tablepidBindingSource8;
        private System.Windows.Forms.Button btnlistele;
        public System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label lblseferno;
        private System.Windows.Forms.ComboBox cbseferno;
        private System.Windows.Forms.Button btnara;
        private System.Windows.Forms.Button btnsefer;
        private System.Windows.Forms.DateTimePicker dtvarissaati;
        private System.Windows.Forms.ComboBox cbtrenadi;
        private System.Windows.Forms.DateTimePicker dtkalkissaati;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbvarisyeri;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbkalkisyeri;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbaciklama;
        private System.Windows.Forms.Button btnekle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnduzenle;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.BindingSource pidserverDataSetBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tRENADIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sEFERNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kALKISYERIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vARISYERIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kALKISSAATIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vARISSAATIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aCIKLAMADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button btnsaat;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
    }
}

