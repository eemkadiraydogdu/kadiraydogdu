﻿namespace pid_deneme1
{
    partial class formlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btngiris = new System.Windows.Forms.Button();
            this.txusername = new System.Windows.Forms.TextBox();
            this.txpassword = new System.Windows.Forms.MaskedTextBox();
            this.btnvazgec = new System.Windows.Forms.Button();
            this.lblsifre = new System.Windows.Forms.Label();
            this.lblkullanici = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btngiris
            // 
            this.btngiris.Location = new System.Drawing.Point(69, 144);
            this.btngiris.Name = "btngiris";
            this.btngiris.Size = new System.Drawing.Size(75, 23);
            this.btngiris.TabIndex = 0;
            this.btngiris.Text = "Giriş";
            this.btngiris.UseVisualStyleBackColor = true;
            this.btngiris.Click += new System.EventHandler(this.btngiris_Click);
            // 
            // txusername
            // 
            this.txusername.Location = new System.Drawing.Point(116, 62);
            this.txusername.Name = "txusername";
            this.txusername.Size = new System.Drawing.Size(100, 20);
            this.txusername.TabIndex = 1;
            // 
            // txpassword
            // 
            this.txpassword.Location = new System.Drawing.Point(116, 97);
            this.txpassword.Name = "txpassword";
            this.txpassword.PasswordChar = '*';
            this.txpassword.Size = new System.Drawing.Size(100, 20);
            this.txpassword.TabIndex = 2;
            // 
            // btnvazgec
            // 
            this.btnvazgec.Location = new System.Drawing.Point(166, 144);
            this.btnvazgec.Name = "btnvazgec";
            this.btnvazgec.Size = new System.Drawing.Size(75, 23);
            this.btnvazgec.TabIndex = 0;
            this.btnvazgec.Text = "Vazgeç";
            this.btnvazgec.UseVisualStyleBackColor = true;
            this.btnvazgec.Click += new System.EventHandler(this.btnvazgec_Click);
            // 
            // lblsifre
            // 
            this.lblsifre.AutoSize = true;
            this.lblsifre.Location = new System.Drawing.Point(75, 100);
            this.lblsifre.Name = "lblsifre";
            this.lblsifre.Size = new System.Drawing.Size(28, 13);
            this.lblsifre.TabIndex = 3;
            this.lblsifre.Text = "Şifre";
            // 
            // lblkullanici
            // 
            this.lblkullanici.AutoSize = true;
            this.lblkullanici.Location = new System.Drawing.Point(45, 65);
            this.lblkullanici.Name = "lblkullanici";
            this.lblkullanici.Size = new System.Drawing.Size(64, 13);
            this.lblkullanici.TabIndex = 3;
            this.lblkullanici.Text = "Kullanıcı Adı";
            // 
            // formlogin
            // 
            this.AcceptButton = this.btngiris;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(315, 243);
            this.Controls.Add(this.lblkullanici);
            this.Controls.Add(this.lblsifre);
            this.Controls.Add(this.txpassword);
            this.Controls.Add(this.txusername);
            this.Controls.Add(this.btnvazgec);
            this.Controls.Add(this.btngiris);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "formlogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "formlogin";
            this.Load += new System.EventHandler(this.formlogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btngiris;
        private System.Windows.Forms.TextBox txusername;
        private System.Windows.Forms.MaskedTextBox txpassword;
        private System.Windows.Forms.Button btnvazgec;
        private System.Windows.Forms.Label lblsifre;
        private System.Windows.Forms.Label lblkullanici;
    }
}