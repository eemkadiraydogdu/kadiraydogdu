﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pid_deneme1
{
    public partial class formsefer : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-4UO9E27\\SQLEXPRESS;Initial Catalog=pid_server;Integrated Security=True");
        public formsefer()
        {
            InitializeComponent();
        }

        private void formsefer_Load(object sender, EventArgs e)
        {
            // TODO: Bu kod satırı 'pid_serverDataSet2.table_pid' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            this.table_pidTableAdapter1.Fill(this.pid_serverDataSet2.table_pid);
            // TODO: Bu kod satırı 'pid_serverDataSet.table_pid' tablosuna veri yükler. Bunu gerektiği şekilde taşıyabilir, veya kaldırabilirsiniz.
            //this.table_pidTableAdapter.Fill(this.pid_serverDataSet.table_pid);

        }

        void sefer_listele()
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "select * FROM table_pid ORDER BY KALKIS_SAATI ASC";
                SqlDataAdapter adpr = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adpr.Fill(ds, "table_pid");
                dataGridView2.DataSource = ds.Tables["table_pid"];
                dataGridView2.Columns[0].Visible = false;
                dataGridView2.Columns[5].DefaultCellStyle.Format = "HH\\:mm";
                dataGridView2.Columns[6].DefaultCellStyle.Format = "HH\\:mm";
                baglanti.Close();
            }
        }


        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }



        private void btnsefer_Click(object sender, EventArgs e)
        {
            sefer_listele();
        }

        private void btnekle_Click_1(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "INSERT INTO table_pid (TREN_ADI,SEFER_NO,KALKIS_YERI,VARIS_YERI,KALKIS_SAATI,VARIS_SAATI,ACIKLAMA) VALUES ('" + cbtrenadi.Text + "','" + cbseferno.Text + "','" + cbkalkisyeri.Text + "','" + cbvarisyeri.Text + "','" + dtkalkissaati.Value.ToShortTimeString() + "','" + dtvarissaati.Value.ToShortTimeString() + "','" + tbaciklama.Text + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                baglanti.Close();
                sefer_listele();
                MessageBox.Show("Ekleme Başarılı");

            }
        }

        private void btnduzenle_Click_1(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "UPDATE table_pid SET TREN_ADI='" + cbtrenadi.Text + "',SEFER_NO='" + cbseferno.Text + "',KALKIS_YERI='" + cbkalkisyeri.Text + "',VARIS_YERI='" + cbvarisyeri.Text + "',KALKIS_SAATI='" + dtkalkissaati.Value.ToShortTimeString() + "',VARIS_SAATI='" + dtvarissaati.Value.ToShortTimeString() + "',ACIKLAMA='" + tbaciklama.Text + "' WHERE id=@numara";
                cmd.Parameters.AddWithValue("@numara", dataGridView2.CurrentRow.Cells[0].Value.ToString());
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                baglanti.Close();
                sefer_listele();
                MessageBox.Show("Düzenleme Başarılı");

            }
        }

        private void btnsil_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Seçili Öğeyi silmek istiyor musunuz?", "DİKKAT", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = baglanti;
                    cmd.CommandText = "DELETE FROM table_pid WHERE id=@numara";
                    cmd.Parameters.AddWithValue("@numara", dataGridView2.CurrentRow.Cells[0].Value.ToString());
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    baglanti.Close();
                    sefer_listele();
                    MessageBox.Show("Silme Başarılı");

                }
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void formsefer_FormClosed(object sender, FormClosedEventArgs e)
        {
           
        }
    }
}
