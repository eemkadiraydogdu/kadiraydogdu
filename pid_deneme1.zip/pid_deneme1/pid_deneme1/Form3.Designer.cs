﻿namespace pid_deneme1
{
    partial class formsefer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formsefer));
            this.btnsefer = new System.Windows.Forms.Button();
            this.dtvarissaati = new System.Windows.Forms.DateTimePicker();
            this.cbtrenadi = new System.Windows.Forms.ComboBox();
            this.dtkalkissaati = new System.Windows.Forms.DateTimePicker();
            this.cbvarisyeri = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbkalkisyeri = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbaciklama = new System.Windows.Forms.TextBox();
            this.btnekle = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnduzenle = new System.Windows.Forms.Button();
            this.btnsil = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tRENADIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sEFERNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kALKISYERIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vARISYERIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kALKISSAATIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vARISSAATIDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aCIKLAMADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablepidBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.pidserverDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pid_serverDataSet = new pid_deneme1.pid_serverDataSet();
            this.tablepidBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pid_serverDataSet2 = new pid_deneme1.pid_serverDataSet2();
            this.label8 = new System.Windows.Forms.Label();
            this.btnara = new System.Windows.Forms.Button();
            this.tablepidBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pidserverDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.table_pidTableAdapter1 = new pid_deneme1.pid_serverDataSet2TableAdapters.table_pidTableAdapter();
            this.table_pidTableAdapter = new pid_deneme1.pid_serverDataSetTableAdapters.table_pidTableAdapter();
            this.cbseferno = new System.Windows.Forms.ComboBox();
            this.lblseferno = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSet2BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnsefer
            // 
            this.btnsefer.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnsefer.Location = new System.Drawing.Point(42, 360);
            this.btnsefer.Name = "btnsefer";
            this.btnsefer.Size = new System.Drawing.Size(177, 42);
            this.btnsefer.TabIndex = 29;
            this.btnsefer.Text = "Sefer Listesi";
            this.btnsefer.UseVisualStyleBackColor = true;
            this.btnsefer.Click += new System.EventHandler(this.btnsefer_Click);
            // 
            // dtvarissaati
            // 
            this.dtvarissaati.CustomFormat = "HH:mm";
            this.dtvarissaati.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtvarissaati.Location = new System.Drawing.Point(100, 152);
            this.dtvarissaati.Name = "dtvarissaati";
            this.dtvarissaati.Size = new System.Drawing.Size(104, 20);
            this.dtvarissaati.TabIndex = 27;
            // 
            // cbtrenadi
            // 
            this.cbtrenadi.FormattingEnabled = true;
            this.cbtrenadi.Location = new System.Drawing.Point(100, 17);
            this.cbtrenadi.Name = "cbtrenadi";
            this.cbtrenadi.Size = new System.Drawing.Size(121, 21);
            this.cbtrenadi.TabIndex = 24;
            // 
            // dtkalkissaati
            // 
            this.dtkalkissaati.CustomFormat = "HH:mm";
            this.dtkalkissaati.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtkalkissaati.Location = new System.Drawing.Point(100, 126);
            this.dtkalkissaati.Name = "dtkalkissaati";
            this.dtkalkissaati.Size = new System.Drawing.Size(104, 20);
            this.dtkalkissaati.TabIndex = 28;
            // 
            // cbvarisyeri
            // 
            this.cbvarisyeri.FormattingEnabled = true;
            this.cbvarisyeri.Items.AddRange(new object[] {
            "ADANA   ",
            "AKSEHIR ",
            "ANKARA  ",
            "ARIFIYE  ",
            "BEYSEHR",
            "E.SEHIR ",
            "EREGLI  ",
            "ISTANBL ",
            "IST-PNDK",
            "IZMIR   ",
            "KARAMAN ",
            "KONYA   ",
            "POLATLI "});
            this.cbvarisyeri.Location = new System.Drawing.Point(100, 99);
            this.cbvarisyeri.Name = "cbvarisyeri";
            this.cbvarisyeri.Size = new System.Drawing.Size(121, 21);
            this.cbvarisyeri.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(24, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Kalkış Yeri";
            // 
            // cbkalkisyeri
            // 
            this.cbkalkisyeri.FormattingEnabled = true;
            this.cbkalkisyeri.Items.AddRange(new object[] {
            "ADANA   ",
            "AKSEHIR ",
            "ANKARA  ",
            "ARIFIYE  ",
            "BEYSEHR",
            "E.SEHIR ",
            "EREGLI  ",
            "ISTANBL ",
            "IST-PNDK",
            "IZMIR   ",
            "KARAMAN ",
            "KONYA   ",
            "POLATLI "});
            this.cbkalkisyeri.Location = new System.Drawing.Point(100, 72);
            this.cbkalkisyeri.Name = "cbkalkisyeri";
            this.cbkalkisyeri.Size = new System.Drawing.Size(121, 21);
            this.cbkalkisyeri.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(29, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Varış Yeri";
            // 
            // tbaciklama
            // 
            this.tbaciklama.Location = new System.Drawing.Point(100, 178);
            this.tbaciklama.Name = "tbaciklama";
            this.tbaciklama.Size = new System.Drawing.Size(121, 20);
            this.tbaciklama.TabIndex = 17;
            // 
            // btnekle
            // 
            this.btnekle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnekle.Location = new System.Drawing.Point(100, 219);
            this.btnekle.Name = "btnekle";
            this.btnekle.Size = new System.Drawing.Size(82, 25);
            this.btnekle.TabIndex = 14;
            this.btnekle.Text = "Ekle";
            this.btnekle.UseVisualStyleBackColor = true;
            this.btnekle.Click += new System.EventHandler(this.btnekle_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(18, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Kalkış Saati";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(30, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Açıklama";
            // 
            // btnduzenle
            // 
            this.btnduzenle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnduzenle.Location = new System.Drawing.Point(98, 250);
            this.btnduzenle.Name = "btnduzenle";
            this.btnduzenle.Size = new System.Drawing.Size(84, 23);
            this.btnduzenle.TabIndex = 16;
            this.btnduzenle.Text = "Düzenle";
            this.btnduzenle.UseVisualStyleBackColor = true;
            this.btnduzenle.Click += new System.EventHandler(this.btnduzenle_Click_1);
            // 
            // btnsil
            // 
            this.btnsil.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnsil.Location = new System.Drawing.Point(98, 279);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(84, 25);
            this.btnsil.TabIndex = 15;
            this.btnsil.Text = "Sil";
            this.btnsil.UseVisualStyleBackColor = true;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(23, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Varış Saati";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.tRENADIDataGridViewTextBoxColumn,
            this.sEFERNODataGridViewTextBoxColumn,
            this.kALKISYERIDataGridViewTextBoxColumn,
            this.vARISYERIDataGridViewTextBoxColumn,
            this.kALKISSAATIDataGridViewTextBoxColumn,
            this.vARISSAATIDataGridViewTextBoxColumn,
            this.aCIKLAMADataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.tablepidBindingSource2;
            this.dataGridView2.Location = new System.Drawing.Point(265, 43);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(719, 397);
            this.dataGridView2.TabIndex = 30;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "id";
            this.Column1.HeaderText = "id";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // tRENADIDataGridViewTextBoxColumn
            // 
            this.tRENADIDataGridViewTextBoxColumn.DataPropertyName = "TREN_ADI";
            this.tRENADIDataGridViewTextBoxColumn.HeaderText = "TREN ADI";
            this.tRENADIDataGridViewTextBoxColumn.Name = "tRENADIDataGridViewTextBoxColumn";
            // 
            // sEFERNODataGridViewTextBoxColumn
            // 
            this.sEFERNODataGridViewTextBoxColumn.DataPropertyName = "SEFER_NO";
            this.sEFERNODataGridViewTextBoxColumn.HeaderText = "SEFER NO";
            this.sEFERNODataGridViewTextBoxColumn.Name = "sEFERNODataGridViewTextBoxColumn";
            // 
            // kALKISYERIDataGridViewTextBoxColumn
            // 
            this.kALKISYERIDataGridViewTextBoxColumn.DataPropertyName = "KALKIS_YERI";
            this.kALKISYERIDataGridViewTextBoxColumn.HeaderText = "KALKIŞ YERİ";
            this.kALKISYERIDataGridViewTextBoxColumn.Name = "kALKISYERIDataGridViewTextBoxColumn";
            // 
            // vARISYERIDataGridViewTextBoxColumn
            // 
            this.vARISYERIDataGridViewTextBoxColumn.DataPropertyName = "VARIS_YERI";
            this.vARISYERIDataGridViewTextBoxColumn.HeaderText = "VARIŞ YERİ";
            this.vARISYERIDataGridViewTextBoxColumn.Name = "vARISYERIDataGridViewTextBoxColumn";
            // 
            // kALKISSAATIDataGridViewTextBoxColumn
            // 
            this.kALKISSAATIDataGridViewTextBoxColumn.DataPropertyName = "KALKIS_SAATI";
            this.kALKISSAATIDataGridViewTextBoxColumn.HeaderText = "KALKIŞ SAATİ";
            this.kALKISSAATIDataGridViewTextBoxColumn.Name = "kALKISSAATIDataGridViewTextBoxColumn";
            // 
            // vARISSAATIDataGridViewTextBoxColumn
            // 
            this.vARISSAATIDataGridViewTextBoxColumn.DataPropertyName = "VARIS_SAATI";
            this.vARISSAATIDataGridViewTextBoxColumn.HeaderText = "VARIŞ SAATİ";
            this.vARISSAATIDataGridViewTextBoxColumn.Name = "vARISSAATIDataGridViewTextBoxColumn";
            // 
            // aCIKLAMADataGridViewTextBoxColumn
            // 
            this.aCIKLAMADataGridViewTextBoxColumn.DataPropertyName = "ACIKLAMA";
            this.aCIKLAMADataGridViewTextBoxColumn.HeaderText = "AÇIKLAMA";
            this.aCIKLAMADataGridViewTextBoxColumn.Name = "aCIKLAMADataGridViewTextBoxColumn";
            // 
            // tablepidBindingSource2
            // 
            this.tablepidBindingSource2.DataMember = "table_pid";
            this.tablepidBindingSource2.DataSource = this.pidserverDataSetBindingSource;
            // 
            // pidserverDataSetBindingSource
            // 
            this.pidserverDataSetBindingSource.DataSource = this.pid_serverDataSet;
            this.pidserverDataSetBindingSource.Position = 0;
            // 
            // pid_serverDataSet
            // 
            this.pid_serverDataSet.DataSetName = "pid_serverDataSet";
            this.pid_serverDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tablepidBindingSource1
            // 
            this.tablepidBindingSource1.DataMember = "table_pid";
            this.tablepidBindingSource1.DataSource = this.pid_serverDataSet2;
            // 
            // pid_serverDataSet2
            // 
            this.pid_serverDataSet2.DataSetName = "pid_serverDataSet2";
            this.pid_serverDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(33, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Tren Adı";
            // 
            // btnara
            // 
            this.btnara.Location = new System.Drawing.Point(103, 310);
            this.btnara.Name = "btnara";
            this.btnara.Size = new System.Drawing.Size(75, 23);
            this.btnara.TabIndex = 31;
            this.btnara.Text = "Ara";
            this.btnara.UseVisualStyleBackColor = true;
            // 
            // tablepidBindingSource
            // 
            this.tablepidBindingSource.DataMember = "table_pid";
            this.tablepidBindingSource.DataSource = this.pidserverDataSetBindingSource;
            // 
            // pidserverDataSet2BindingSource
            // 
            this.pidserverDataSet2BindingSource.DataSource = this.pid_serverDataSet2;
            this.pidserverDataSet2BindingSource.Position = 0;
            // 
            // table_pidTableAdapter1
            // 
            this.table_pidTableAdapter1.ClearBeforeFill = true;
            // 
            // table_pidTableAdapter
            // 
            this.table_pidTableAdapter.ClearBeforeFill = true;
            // 
            // cbseferno
            // 
            this.cbseferno.FormattingEnabled = true;
            this.cbseferno.Location = new System.Drawing.Point(100, 45);
            this.cbseferno.Name = "cbseferno";
            this.cbseferno.Size = new System.Drawing.Size(121, 21);
            this.cbseferno.TabIndex = 32;
            // 
            // lblseferno
            // 
            this.lblseferno.AutoSize = true;
            this.lblseferno.Location = new System.Drawing.Point(32, 50);
            this.lblseferno.Name = "lblseferno";
            this.lblseferno.Size = new System.Drawing.Size(49, 13);
            this.lblseferno.TabIndex = 33;
            this.lblseferno.Text = "Sefer No";
            // 
            // formsefer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 469);
            this.Controls.Add(this.lblseferno);
            this.Controls.Add(this.cbseferno);
            this.Controls.Add(this.btnara);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnsefer);
            this.Controls.Add(this.dtvarissaati);
            this.Controls.Add(this.cbtrenadi);
            this.Controls.Add(this.dtkalkissaati);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbvarisyeri);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbkalkisyeri);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbaciklama);
            this.Controls.Add(this.btnekle);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnduzenle);
            this.Controls.Add(this.btnsil);
            this.Controls.Add(this.label6);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "formsefer";
            this.Text = "Form3";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.formsefer_FormClosed);
            this.Load += new System.EventHandler(this.formsefer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pid_serverDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablepidBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pidserverDataSet2BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsefer;
        private System.Windows.Forms.DateTimePicker dtvarissaati;
        private System.Windows.Forms.ComboBox cbtrenadi;
        private System.Windows.Forms.DateTimePicker dtkalkissaati;
        private System.Windows.Forms.ComboBox cbvarisyeri;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbkalkisyeri;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbaciklama;
        private System.Windows.Forms.Button btnekle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnduzenle;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label8;
        private pid_serverDataSet pid_serverDataSet;
        private System.Windows.Forms.Button btnara;
        private System.Windows.Forms.BindingSource pidserverDataSetBindingSource;
        private System.Windows.Forms.BindingSource tablepidBindingSource;
        private pid_serverDataSetTableAdapters.table_pidTableAdapter table_pidTableAdapter;
        private System.Windows.Forms.BindingSource pidserverDataSet2BindingSource;
        private pid_serverDataSet2 pid_serverDataSet2;
        private System.Windows.Forms.BindingSource tablepidBindingSource1;
        private pid_serverDataSet2TableAdapters.table_pidTableAdapter table_pidTableAdapter1;
        private System.Windows.Forms.BindingSource tablepidBindingSource2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tRENADIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sEFERNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kALKISYERIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vARISYERIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kALKISSAATIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vARISSAATIDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aCIKLAMADataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox cbseferno;
        private System.Windows.Forms.Label lblseferno;
    }
}