﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pid_deneme1
{
    public partial class formlogin : Form
    {
        
        public formlogin()
        {
            InitializeComponent();
        }

        private void formlogin_Load(object sender, EventArgs e)
        {

        }

        private void btngiris_Click(object sender, EventArgs e)
        {
            if (txusername.Text==""||txpassword.Text=="")
            {
                MessageBox.Show("Lütfen Kullacı Adı ve Şifresi Alın");
                return;
            }

            try
            {                          
                    //SqlCommand cmd = new SqlCommand();
                    //cmd.Connection = baglanti;
                    //cmd.CommandText = "SELECT from table_login WHERE username=@username and password=@password";
                    //cmd.Parameters.AddWithValue("@username", txusername.Text);
                    //cmd.Parameters.AddWithValue("@password", txpassword.Text);                 
                    //SqlDataAdapter adpr = new SqlDataAdapter(cmd);
                    //DataSet ds = new DataSet();
                    //baglanti.Close();
                    //int count = ds.Tables[0].Rows.Count;
                    SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-4UO9E27\\SQLEXPRESS;Initial Catalog=pid_server;Integrated Security=True");
                    baglanti.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = baglanti;
                    cmd.CommandText = "SELECT * from table_login WHERE username='"+txusername.Text+"' and password='"+txpassword.Text+"'";
                    SqlDataAdapter adpr = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    cmd.ExecuteNonQuery();
                    cmd.Dispose();             

                    if (cmd.ExecuteReader().Read())
                    {
                        baglanti.Close();
                        //MessageBox.Show("Giriş Başarılı");
                        this.Hide();
                        frmmain fm = new frmmain();
                        fm.Show();
                    }
                    else
                    {
                        baglanti.Close();
                        MessageBox.Show("Hatalı kullanıcı adı veya şifre");
                    }

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            }

        private void btnvazgec_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
    }

