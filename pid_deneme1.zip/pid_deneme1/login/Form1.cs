﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class frmlogin : Form
    {
        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-4UO9E27\\SQLEXPRESS;Initial Catalog=pid_server;Integrated Security=True");
        public frmlogin()
        {
            InitializeComponent();
        }

        private void btngiris_Click(object sender, EventArgs e)
        {
            if (baglanti.State == ConnectionState.Closed)
            {
                baglanti.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = baglanti;
                cmd.CommandText = "INSERT INTO table_pid (TREN_ADI,KALKIS_YERI,VARIS_YERI,KALKIS_SAATI,VARIS_SAATI,ACIKLAMA) VALUES ('" + cbtrenadi.Text + "','" + cbkalkisyeri.Text + "','" + cbvarisyeri.Text + "','" + dtkalkissaati.Value.ToShortTimeString() + "','" + dtvarissaati.Value.ToShortTimeString() + "','" + tbaciklama.Text + "')";
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                baglanti.Close();
                listeleme();
                MessageBox.Show("Giriş Başarılı");

        }

        private void btnvazgec_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
